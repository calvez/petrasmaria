<aside class="left-off-canvas-menu" aria-hidden="true">
    <?php foundationpress_mobile_off_canvas(); ?>
</aside>